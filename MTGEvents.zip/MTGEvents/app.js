var express = require('express');
var connectionController = require('./routes/connectionController.js');
var rootController = require('./routes/rootController.js');
var app = express();

// server setup
app.set('view engine', 'ejs');
app.use('/resources', express.static('resources'));
app.use('/utilities', express.static('utilities'));

// set routes
app.use('/connections', connectionController);
app.use('/', rootController);

// server listening to port
app.listen(8080, function() {
    console.log('server starting');
    console.log('listening on port 8080');
})

