// Used for button functionality on connection details page
function getElement(id) {
    return document.getElementById(id);
}

// listeners for all buttons
window.onload = function() {
    getElement("btnYes").onclick = loadWindow;
    getElement("btnNo").onclick = loadWindow;
    getElement("btnMaybe").onclick = loadWindow;
}

function loadWindow() {
    window.location.href = "/savedConnections";
}