// Database file
var connection = require("../models/connection");

// Array of connections for pseudo-database
var database = [
    connection.connection("Ala34jKDle", "Kaldheim Qualifier Weekend", "Wizards of the Coast", "Pro", "Finishing the January 2021 Ranked Season as a top 1200 Mythic-ranked player,Finishing with six match wins during the previous month's Qualifier Weekend,Qualifing for the Zendikar Rising Championship,Being a member of the Magic: The Gather Pro Tour Hall of Fame", new Date("Febuary 27, 2021 06:00:00"), "MTG Arena"),
    connection.connection("Basd23HD5g", "League Weekend", "Wizards of the Coast", "Pro", "Each weekend will use two formats one each day,Each day is six (6) Swiss rounds,Pools will be reseeded every three rounds based on updated league standings,Each match win is worth one (1) point toward league standing", new Date("Febuary 27, 2021 06:00:00"), "MTG Arena"),
    connection.connection("CfdASwe45g", "2020 Magic Champions Showcase Season 2", "Wizards of the Coast", "Pro", "30 Event Tickets,300 Play Points", new Date("March 13, 2021 08:00:00"), "Magic Online"),
    connection.connection("DkglaSA32t", "2020 Magic Champions Showcase Season 3", "Wizards of the Coast", "Pro", "30 Event Tickets,300 Play Points", new Date("March 14, 2021 08:00:00"), "Magic Online"),
    connection.connection("EFSasf635l", "Kaldheim Championship", "Wizards of the Coast", "Pro", "Top 16 from either day of the Qualifier Tournament", new Date("March 26, 2021 06:00:00"), "MTG Arena"),
    connection.connection("F52GSsfsGs", "Sealed | Kaldheim", "Wizards of the Coast", "Casual", "Unlike constructed games—where you arrive with your strategically created deck—in a sealed deck tournament, you build a new deck from six unopened booster packs at the start of the event.", new Date("January 28, 2021 08:00:00"), "MTG Arena"),
    connection.connection("GfdaASD653", "Quick Draft | Zendikar Rising", "Wizards of the Coast", "Casual", "Players draft three Packs which contain 15 cards (10 commons, 3 uncommons, and 1 rare or mythic rare, 1 basic or common land). This means after picking one card the pack is passed on to the next player (during the closed beta other players are replaced with an AI). This continues until all cards have been picked. Players then build 40-card-minimum decks. The amount of basic lands is unlimited, they are provided to the player for free.", new Date("January 29, 2021 08:00:00"), "MTG Arena"),
    connection.connection("Hgsd7L9Bvx", "FNM at Home | Treasure Singleton", "Wizards of the Coast", "Casual", "Friday Night Magic (or FNM) is a format of Magic: The Gathering tournaments, held on Friday nights in gaming stores and associations all across the world. They are designed to be a beginner-friendly introduction to organized play. FNM has currently been moved to online for the duration of the pandemic.", new Date("Febuary 5, 2021 18:00:00"), "MTG Arena"),
    connection.connection("IgE5Hu8JHy", "Standard Metagame Challenge", "Wizards of the Coast", "Casual", "Standard Metagame Challenge is a special event that gives players the opportunity to win huge rewards in a relatively new metagame where the new cards from the latest set are being tested, and decklists are being refined.", new Date("Febuary 6, 2021 18:00:00"), "MTG Arena"),
    connection.connection("Jbv32GjKa3", "FNM at Home | Standard", "Wizards of the Coast", "Casual", "Friday Night Magic (or FNM) is a format of Magic: The Gathering tournaments, held on Friday nights in gaming stores and associations all across the world. They are designed to be a beginner-friendly introduction to organized play. FNM has currently been moved to online for the duration of the pandemic.", new Date("Febuary 11, 2021 18:00:00"), "MTG Arena"),
    connection.connection("KnxRS486GD", "Kaldheim | Constructed", "Wizards of the Coast", "Casual", "In Constructed format tournaments, players build their deck in advance of the tournament. Constructed decks must contain a minimum of 60 cards.", new Date("Febuary 13, 2021 18:00:00"), "MTG Arena")
];

// gets all connections
var getConnections = function() {
    return database;
}

// gets specific connection based on connectionID
var getConnection = function(connectionID) {
    var returnConnection = null;
    database.forEach(function(item) {
        if (item.getId() == connectionID) {
            returnConnection = item;
        }
    });
    return returnConnection;
}

module.exports.getConnections = getConnections;
module.exports.getConnection = getConnection;