// Used for button functionality on savedConnections page
// Generic button classes for scalibility
window.onload = function () {
    var buttons = document.getElementsByClassName("scbtn");
    for (var i = 0; i < buttons.length; i++) {
        if(buttons[i].classList.contains("update")) {
            buttons[i].addEventListener("click", function() {
                window.location.href = "connection.ejs";
            });
        } else {
            buttons[i].addEventListener("click", function() {
                window.location.href = "savedConnections.ejs";
            });
        }
    }
}