var connection = function(id, name, host, topic, details, date, location) {
    // Connection object
    var connectionModel = {
        // fields
        id: id, 
        name: name,
        host: host, 
        topic: topic, 
        details: details, 
        date: date,
        location: location,
        // getters
        getId: function() {
            return this.id;
        },
        getName: function () {
            return this.name;
        },
        getHost: function() {
            return this.host;
        },
        getTopic: function () {
            return this.topic;
        },
        getDetails: function () {
            return this.details;
        },
        getDate: function () {
            return this.date;
        },
        getLocation: function () {
            return this.location;
        },
        // setters
        setId: function(newID) {
            this.id = newID;
        },
        setName: function(newName) {
            this.name = newName;
        },
        setHost: function(newHost) {
            this.host = newHost;
        },
        setTopic: function(newTopic) {
            this.topic = newTopic;
        },
        setDetails: function(newDetails) {
            this.details = newDetails;
        },
        setDate: function(newDate) {
            this.date = newDate;
        },
        setLocation: function(newLocation) {
            this.location = newLocation;
        }
    };
    return connectionModel;
}

module.exports.connection = connection;