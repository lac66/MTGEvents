// rootController used for all pages except connections
var express = require('express');

// set up router
var router = express.Router();

// gets pages
router.get('/', function(req, res) {
    res.render('index');
});

router.get('/savedConnections', function(req, res) {
    res.render('savedConnections')
});

router.get('/newConnection', function(req, res) {
    res.render('newConnection');
});

router.get('/about', function(req, res) {
    res.render('about');
});

router.get('/contact', function(req, res) {
    res.render('contact');
});

router.get('/*', function(req, res) {
    res.render('index');
});

module.exports = router;