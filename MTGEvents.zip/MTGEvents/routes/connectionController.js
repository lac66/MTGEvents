var express = require('express');
var connectionDB = require('../utilities/connectionDB');

// set up router and database connection
var router = express.Router();
var database = connectionDB.getConnections();

// get links, redirects are for smooth transitions from details page
router.get('/', function(req, res) {
    res.render('connections', {data: database});
});

router.get('/newConnection', function(req, res) {
    res.redirect('/newConnection');
});

router.get('/savedConnections', function(req, res) {
    res.redirect('/savedConnections');
});

router.get('/about', function(req, res) {
    res.redirect('/about');
});

router.get('/contact', function(req, res) {
    res.redirect('/contact');
});

// :id to get specific connection
router.get('/:id', function(req, res) {
    var connection = connectionDB.getConnection(req.params.id);
    if (connection == undefined) {
        res.redirect('/connections');
    } else {
        res.render('connection', {data: connection});
    }
});

router.get('/*', function(req, res) {
    res.redirect('/connections');
});

module.exports = router;